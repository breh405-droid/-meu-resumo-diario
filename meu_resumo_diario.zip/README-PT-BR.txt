MEU RESUMO DIÁRIO — VERSÃO INICIAL

O projeto contém um app web com manchetes RSS, previsão do tempo de Itapetininga e leitura em voz alta pelo navegador.

IMPORTANTE: a notificação automática ainda exige configuração externa. Ela usa OneSignal e uma Netlify Scheduled Function. Não funciona apenas ao enviar os arquivos ao Netlify.

PUBLICAÇÃO
1. Extraia o ZIP.
2. Publique o projeto no Netlify por meio de um repositório Git ou Netlify CLI; deploy manual por arrastar arquivos não executa a função agendada.
3. Ative HTTPS no domínio publicado.

CONFIGURAR NOTIFICAÇÕES
1. Crie um app Web Push no OneSignal e informe o domínio HTTPS exato do seu site.
2. Copie o App ID público e substitua COLOQUE_SEU_ONESIGNAL_APP_ID no index.html.
3. No Netlify, em Site configuration > Environment variables, adicione ONESIGNAL_APP_ID e ONESIGNAL_REST_API_KEY. A REST API Key é secreta e nunca deve ser colocada no HTML.
4. Faça novo deploy.
5. Cada pessoa precisa abrir o site no aparelho e aceitar as notificações no botão “Ativar notificações”.
6. Teste antes de confiar no envio diário.

HORÁRIO: a função está programada para 11:00 UTC, equivalente a 08:00 no horário de Brasília (UTC-3). O horário é aproximado e pode exigir ajuste se o fuso mudar.

ÁUDIO: o botão lê manchetes e previsão usando SpeechSynthesis do navegador. Não gera arquivo MP3 e depende das vozes disponíveis no aparelho.

FONTES: RSS configurados em netlify/functions/summary.js; previsão via Open-Meteo; notificações via OneSignal.
